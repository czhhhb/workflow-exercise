package com.czhhhb.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionRecommend implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        //实现图书推荐功能，监听实现gui 并且调用数据库操作
        //随机产生一批图书产生到界面上，界面自己做 也可以参考图书查看的界面
    }
}
